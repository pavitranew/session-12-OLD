

declare var componentHandler: any;
