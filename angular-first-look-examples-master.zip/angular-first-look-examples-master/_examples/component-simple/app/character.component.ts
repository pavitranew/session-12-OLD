import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'my-character',
   templateUrl: './character.component.html'
})
export class CharacterComponent {
  name = 'Han Solo';
}
