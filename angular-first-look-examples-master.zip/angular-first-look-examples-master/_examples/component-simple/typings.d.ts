 

declare var componentHandler: any;
