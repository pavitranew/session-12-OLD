export let CONFIG = {
  baseUrls: {
    characters: 'api/characters.json',
    vehicles: 'api/vehicles.json'
  }
};
