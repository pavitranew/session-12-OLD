"use strict";
var Character = (function () {
    function Character(id, name) {
        this.id = id;
        this.name = name;
    }
    return Character;
}());
exports.Character = Character;
//# sourceMappingURL=character.js.map