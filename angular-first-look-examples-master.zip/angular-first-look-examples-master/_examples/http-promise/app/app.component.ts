import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'my-app',
  template: '<my-vehicle-list></my-vehicle-list>',
})
export class AppComponent {}

